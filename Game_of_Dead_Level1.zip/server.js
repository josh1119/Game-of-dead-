const http = require('http');
const WebSocket = require('ws');
const server = http.createServer();
const wss = new WebSocket.Server({ server });
const clients = new Map();

let light = 'red';
let interval;

function broadcast(data) {
  const msg = JSON.stringify(data);
  for (const ws of clients.keys()) {
    ws.send(msg);
  }
}

function startLightCycle() {
  interval = setInterval(() => {
    light = light === 'red' ? 'green' : 'red';
    broadcast({ type: 'light', light });
  }, 3000);
}

wss.on('connection', ws => {
  const id = Date.now() + Math.random();
  clients.set(ws, { x: 100, eliminated: false });
  ws.send(JSON.stringify({ type: 'init', id, light }));

  ws.on('message', msg => {
    const data = JSON.parse(msg);
    const player = clients.get(ws);
    if (data.type === 'move' && !player.eliminated) {
      if (light === 'red') {
        player.eliminated = true;
      } else {
        player.x += 10;
      }
      broadcast({ type: 'update', id, x: player.x, eliminated: player.eliminated });
    }
  });

  ws.on('close', () => {
    clients.delete(ws);
    broadcast({ type: 'remove', id });
  });

  if (clients.size === 1) {
    startLightCycle();
  }
  broadcast({ type: 'new', id, x: 100, eliminated: false });
});

server.listen(process.env.PORT || 8080, () => {
  console.log('Servidor WebSocket listo');
});